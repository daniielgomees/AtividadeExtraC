#include <stdio.h>
#include <stdlib.h>
#include <time.h>

// Declara��o das fun��es
void exibirVetor(int *array, int tamanho);
void insertionSort(int *array, int tamanho);
void embaralharVetor(int *array, int tamanho);

int main() {
    int tamanho = 50;
    int original[tamanho];
    int copiaBubble[tamanho], copiaInsertion[tamanho], copiaSelection[tamanho];

    for (int i = 0; i < tamanho; i++) { // Preencher o vetor com n�meros de 1 a 50
        original[i] = i + 1;
    }

    srand(time(NULL));
    embaralharVetor(original, tamanho); // Chamada para Gerar n�meros aleat�rios

    printf("\nVetor embaralhado: ");
    exibirVetor(original, tamanho);
    
    for (int i = 0; i < tamanho; i++) copiaInsertion[i] = original[i];	
    insertionSort(copiaInsertion, tamanho);								// Chamada da Ordena��o com Insertion Sort
    
	printf("\nVetor ordenado (Insertion Sort): ");
    exibirVetor(copiaInsertion, tamanho);

    return 0;
}
//FUN��O PARA EXIBIR OS VETORES
void exibirVetor(int *array, int tamanho) {
    for (int i = 0; i < tamanho; i++) {
        printf(" [%d] ", array[i]);
    }
    printf("\n");
}
//FUN��O PARA ORDENA��O INSERTION SORT
void insertionSort(int *array, int tamanho) {
    for (int i = 1; i < tamanho; i++) {
        int chave = array[i];
        int j = i - 1;
        while (j >= 0 && array[j] > chave) {
            array[j + 1] = array[j];
            j--;
        }
        array[j + 1] = chave;
    }
}
//FUN��O PARA PREENCHER O VETOR COM NUMEROS RANDOMICOS NAO REPETIDOS
void embaralharVetor(int *array, int tamanho) {
    for (int i = tamanho - 1; i > 0; i--) {
        int j = rand() % (i + 1);
        int temp = array[i];
        array[i] = array[j];
        array[j] = temp;
    }
}

